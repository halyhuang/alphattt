#!/bin/sh
yaws -i -c wiki.conf
