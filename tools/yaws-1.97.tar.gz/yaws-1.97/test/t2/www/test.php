<? echo "Hello, world!"; ?>
